#ifndef JUEGO_H
#define JUEGO_H
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "../../Libreria/libreria.h"
#include"Nave.h"
	// completar	
	// completar
#include "Definiciones.h"

using namespace std;

class Juego{
	int _tecla;
	bool _gameOver;
	int _puntos;
	bool _resultado;
	Nave* _nave;
	// completar	
	// completar
public:
	Juego();
	~Juego();
	void init();
	bool gameOver();
	void play();
	void input();
	void update();
	void draw();
	void result();
	void display();
};
#endif